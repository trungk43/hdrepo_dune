<?php
	require_once "lib/utils.php";
	require_once "base_menu.php";
	
	class SubMenu extends BaseMenu
	{
		private $user_data;
		
		function __construct($user_data)
		{
			$this->user_data = $user_data;
		}
		
		
		public function generate_menu()
		{
			$data = HD::http_get_document('http://feed.hdrepo.com/v1/sub.php?id=' . $this->user_data['id']);
			$movies = json_decode($data, true);
			
			$menu_items = array();
			
			$folder = true;
			
			foreach ($movies as $movie)
			{
				$movie['param'] = 'http://www.fshare.vn/file/' . $this->user_data['id'];
				$movie['title'] = $movie['name'];
				$movie['sub'] = $movie['link'];
				
				array_push($menu_items, $movie);
			}
			
			if ($folder){
				$this->iconFile = "gui_skin://small_icons/video_file.aai";
				$this->action = PLUGIN_VOD_PLAY_ACTION_ID;
			}
					
			return $this->create_folder_view($menu_items);
		}
	}
?>