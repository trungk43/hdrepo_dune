<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/abstract_controls_screen.php';

///////////////////////////////////////////////////////////////////////////

class DemoSetupScreen extends AbstractControlsScreen
{
    const ID = 'setup';

    ///////////////////////////////////////////////////////////////////////

    public function __construct()
    {
        parent::__construct(self::ID);
    }

    public function do_get_control_defs(&$plugin_cookies)
    {
        $defs = array();

        $show_tv = isset($plugin_cookies->show_tv) ?
            $plugin_cookies->show_tv : 'yes';
        $show_vod = isset($plugin_cookies->show_vod) ?
            $plugin_cookies->show_vod : 'yes';

        $show_ops = array();
        $show_ops['yes'] = 'Yes';
        $show_ops['no'] = 'No';

        $this->add_combobox($defs,
            'show_tv', 'Show TV in main screen:',
            $show_tv, $show_ops, 0, true);

        $this->add_combobox($defs,
            'show_vod', 'Show VOD in main screen:',
            $show_vod, $show_ops, 0, true);

        if (isset($plugin_cookies->email))
            $email = $plugin_cookies->email;
        else
            $email = '';

        $this->add_text_field($defs,
            'email', 'Email',
            $email, false, false, true, true,
            500, true, true);

        if (isset($plugin_cookies->password))
        	$password = $plugin_cookies->password;
        else
        	$password = '';
        
        $this->add_text_field($defs,
        		'password', 'Password',
        		$password, false, false, true, true,
            500, true, true);
			
        return $defs;
    }

    public function get_control_defs(MediaURL $media_url, &$plugin_cookies)
    {
        return $this->do_get_control_defs($plugin_cookies);
    }

    public function handle_user_input(&$user_input, &$plugin_cookies)
    {
        hd_print('Setup: handle_user_input:');
        foreach ($user_input as $key => $value)
            hd_print("  $key => $value");

        if ($user_input->action_type === 'confirm')
        {
            $control_id = $user_input->control_id;
            $new_value = $user_input->{$control_id};
            hd_print("Setup: changing $control_id value to $new_value");

            if ($control_id === 'show_tv')
                $plugin_cookies->show_tv = $new_value;
            else if ($control_id === 'show_vod')
                $plugin_cookies->show_vod = $new_value;
            else if ($control_id === 'email')
                $plugin_cookies->email = $new_value;
            else if ($control_id === 'password')
                $plugin_cookies->password = $new_value;
        }

        return ActionFactory::reset_controls(
            $this->do_get_control_defs($plugin_cookies));
    }
}

///////////////////////////////////////////////////////////////////////////
?>
