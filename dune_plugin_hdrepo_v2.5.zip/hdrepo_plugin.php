<?php
require "main_menu.php";
require "movie_menu.php";
require "sub_menu.php";
require_once 'lib/control_factory.php';
require_once 'lib/action_factory.php';
require_once 'lib/user_input_handler_registry.php';
require_once 'hdrepo_setup_screen.php';
require_once 'hdrepo_search_screen.php';
class HDrepoPlugin implements DunePlugin {
	public static function get_media_url_str($post_data) {
		return MediaURL::encode ( array (
				'screen_id' => 'main_menu',
				'post_data' => $post_data 
		) );
	}
	private $handler;
	public function __construct() {
		$this->handler = new HDrepoSetupScreen ();
		UserInputHandlerRegistry::get_instance ()->register_handler ( $this->handler );
		UserInputHandlerRegistry::get_instance ()->register_handler ( new HDrepoSearchScreen () );
	}
	public function get_folder_view($media_url, &$plugin_cookies) {
		HD::decode_user_data ( $media_url, $media_str, $user_data );
		
		if ($media_str === 'sub_play') {
			$menu = new SubMenu ( $user_data );
			return $menu->generate_menu ();
		} else if ($media_str === 'main_menu') {
			if (! is_null ( $user_data )) {
				if ($user_data ['type'] === 'fshare_file') {
					$menu = new MovieMenu ( $user_data );
				} else {
					$menu = new MainMenu ( $user_data );
				}
			} else {
				$menu = new MainMenu ( null );
			}
			
			return $menu->generate_menu ();
		} else if ($media_str === 'setup') {
			$defs = $this->handler->get_control_defs ( $media_url, $plugin_cookies );
			
			$folder_view = array (
					PluginControlsFolderView::defs => $defs,
					PluginControlsFolderView::initial_sel_ndx => - 1 
			);
			
			return array (
					PluginFolderView::multiple_views_supported => false,
					PluginFolderView::archive => null,
					PluginFolderView::view_kind => PLUGIN_FOLDER_VIEW_CONTROLS,
					PluginFolderView::data => $folder_view 
			);
		}
	}
	public function get_next_folder_view($media_url, &$plugin_cookies) {
	}
	public function get_tv_info($media_url, &$plugin_cookies) {
	}
	public function get_tv_stream_url($media_url, &$plugin_cookies) {
	}
	public function get_vod_info($media_url, &$plugin_cookies) {
	}
	public function get_vod_stream_url($media_url, &$plugin_cookies) {
		return $media_url;
	}
	public function get_regular_folder_items($media_url, $from_ndx, &$plugin_cookies) {
	}
	public function get_day_epg($channel_id, $day_start_tm_sec, &$plugin_cookies) {
	}
	public function get_tv_playback_url($channel_id, $archive_tm_sec, $protect_code, &$plugin_cookies) {
	}
	public function change_tv_favorites($op_type, $channel_id, &$plugin_cookies) {
	}
	public function handle_user_input(&$user_input, &$plugin_cookies) {
		if ($user_input->control_id == 'play') {
			
			// Logout current session
			$ckfile = "/tmp/CURLCOOKIE2";
			$this->logout ( $ckfile );
			
			// Login
			$this->login ( $ckfile, $plugin_cookies->email, $plugin_cookies->password );
			
			HD::decode_user_data ( $user_input->selected_media_url, $media_str, $user_data );
			
			$location = $this->get_redirect ( $ckfile, $user_data ['param'] );
			
			if (strpos ( $location, '.mp4' ) > 0) {
				$location = str_replace ( 'http://', 'http://mp4://', $location );
				hd_print ( $location );
			} else if (strpos ( $location, '.ts' ) > 0) {
				$location = str_replace ( 'http://', 'http://ts://', $location );
				hd_print ( $location );
			}
			
			return array (
					GuiAction::handler_string_id => FILE_PLAY_ACTION_ID,
					GuiAction::data => array (
							FilePlayActionData::url => $location 
					) 
			);
		} else if ($user_input->control_id == 'findsub') {
			HD::decode_user_data ( $user_input->selected_media_url, $media_str, $user_data );
			$fshare_link = $user_data ['param'];
			$link_id = substr ( $fshare_link, strrpos ( $fshare_link, '/' ) + 1 );
				
			return array (
					GuiAction::handler_string_id => PLUGIN_OPEN_FOLDER_ACTION_ID,
					GuiAction::data => array (
							PluginOpenFolderActionData::media_url => HD::encode_user_data('sub_play', array('id' => $link_id)) 
					) 
			);
		} else if ($user_input->control_id == 'stop') {
			exec ( 'ps aux | grep -i createFile | grep -iv grep | awk {\'print $1\'} | xargs kill -9' );
		} else if ($user_input->control_id == 'download' || $user_input->control_id == 'quickplay') {
			$tmp_dir = $this->getFolder ();
			
			if ($tmp_dir == null) {
				return ActionFactory::show_title_dialog ( "Bạn cần phải có thư mục 'hdrepo' trên ổ cứng để chạy chức năng Play using cache." );
			}
			
			$file = '/tmp/mnt/storage/' . $tmp_dir . '/temp.mkv';
			$file2 = 'storage_name://' . $tmp_dir . '/temp.mkv';
			
			if (! file_exists ( $file )) {
				exec ( "dd if=/dev/zero of=$file bs=1M count=1" );
			}
			
			HD::decode_user_data ( $user_input->selected_media_url, $media_str, $user_data );
			
			unlink ( "/tmp/mnt/storage/$tmp_dir/temp.srt" );
			if (isset($user_data ['sub'])){
				exec("wget -q " . $user_data ['sub'] . " -O - | grep '/subtitle/download?mac=' | awk {'print $2'}", $args);
				if (count ( $args ) > 0){
					//href="/subtitle/download?mac=Pgd0yCEMOFdkVYqboaL7KVbLF_YeiqKwsB62_ws6DQEw85TO6wAqzziRN5x0IHS50"
					$sub = str_replace('"', '', $args[0]);
					$sub = str_replace('href=', '', $args[0]);

					exec("wget http://subscene.com$sub -O /tmp/mnt/storage/$tmp_dir/temp.zip");
					exec("cd /tmp/mnt/storage/$tmp_dir/;unzip -o temp.zip | grep 'inflating: .*' | awk {'print $2'}", $args);
					
					if (count ( $args ) > 0){
						exec("cd /tmp/mnt/storage/$tmp_dir/;mv " . $args[0] . " temp.srt");
					}
				}
			}
				
			$fshare_link = $user_data ['param'];
			$link_id = substr ( $fshare_link, strrpos ( $fshare_link, '/' ) + 1 );
			
			exec ( "ps aux | grep -i $link_id | grep -iv grep", $processes );
			
			if (count ( $processes ) > 0) {
				return array (
						GuiAction::handler_string_id => FILE_PLAY_ACTION_ID,
						GuiAction::data => array (
								FilePlayActionData::url => $file2 
						) 
				);
			}
			
			exec ( 'ps aux | grep -i createFile | grep -iv grep | awk {\'print $1\'} | xargs kill -9' );
			
			// Logout current session
			$ckfile = "/tmp/CURLCOOKIE2";
			
			$location = $this->get_redirect ( $ckfile, $fshare_link );
			if (strpos ( $location, 'logout' ) > 0) {
				$this->logout ( $ckfile );
				
				// Login
				$this->login ( $ckfile, $plugin_cookies->email, $plugin_cookies->password );
				$location = $this->get_redirect ( $ckfile, $fshare_link );
			}
			
			$pos1 = strpos ( $location, '/', 8 );
			$pos2 = strrpos ( $location, '/' );
			$param1 = substr ( $location, 7, $pos1 - 7 ); // hostname
			$param2 = substr ( $location, $pos1, $pos2 - $pos1 ); // path
			
			hd_print ( 'location ' . $location );
			
			$pos = strrpos ( $location, '/' );
			if ($pos === false) {
			} else {
				$location = substr ( $location, 0, $pos );
				hd_print ( $file );
				hd_print ( $file2 );
				
				$fileLength = $this->get_size ( $location );
				
				// last 1M
				$len1 = ( int ) substr ( $fileLength, 0, strlen ( $fileLength ) - 6 );
				$len1 -= 1;
				$len2 = substr ( $fileLength, strlen ( $fileLength ) - 6 );
				
				$hdrepo_path = DuneSystem::$properties ["install_dir_path"] . "/bin";
				
				shell_exec ( "$hdrepo_path/createFile $param1 $param2 $file $len1$len2" );
				
				$cmd = "$hdrepo_path/createFile $param1 $param2 $file 0 $link_id> /dev/null 2>/dev/null &";
				hd_print ( $cmd );
				shell_exec ( $cmd );
				
				if ($user_input->control_id == 'download') {
					sleep ( 15 );
				} else {
					sleep ( 3 );
				}
				
				return array (
						GuiAction::handler_string_id => FILE_PLAY_ACTION_ID,
						GuiAction::data => array (
								FilePlayActionData::url => $file2 
						) 
				);
			}
		}
		
		return UserInputHandlerRegistry::get_instance ()->handle_user_input ( $user_input, $plugin_cookies );
	}
	function getFolder() {
		if ($handle = opendir ( '/tmp/mnt/storage/.' )) {
			$blacklist = array (
					'.',
					'..' 
			);
			while ( false !== ($file = readdir ( $handle )) ) {
				if (! in_array ( $file, $blacklist ) && file_exists ( "/tmp/mnt/storage/$file/hdrepo" )) {
					closedir ( $handle );
					return "$file/hdrepo";
				}
			}
			closedir ( $handle );
		}
	}
	function clean($string) {
		// $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
		return preg_replace ( '/[^A-Za-z0-9\-\.\_\s]/', '', $string ); // Removes special chars.
	}
	public function login($ckfile, $email, $password) {
		
		// set POST variables
		$url = 'https://www.fshare.vn/login.php';
		$fields = array (
				'login_useremail' => $email,
				'login_password' => $password,
				'url_refe' => 'https://www.fshare.vn/index.php' 
		);
		
		$fields_string = '';
		
		// url-ify the data for the POST
		foreach ( $fields as $key => $value ) {
			$fields_string .= $key . '=' . $value . '&';
		}
		
		rtrim ( $fields_string, '&' );
		
		// open connection
		$ch = curl_init ();
		
		// set the url, number of POST vars, POST data
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_POST, count ( $fields ) );
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields_string );
		curl_setopt ( $ch, CURLOPT_COOKIEFILE, $ckfile );
		curl_setopt ( $ch, CURLOPT_COOKIEJAR, $ckfile );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0" );
		curl_setopt ( $ch, CURLOPT_REFERER, 'https://www.fshare.vn/login.php' );
		curl_setopt ( $ch, CURLOPT_HEADER, 1 );
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, false );
		
		// execute post
		$result = curl_exec ( $ch );
		curl_close ( $ch );
	}
	public function logout($ckfile) {
		if (! file_exists ( $ckfile )) {
			return;
		}
		
		$ch = curl_init ();
		
		// set the url, number of POST vars, POST data
		curl_setopt ( $ch, CURLOPT_URL, 'https://www.fshare.vn/logout.php' );
		curl_setopt ( $ch, CURLOPT_COOKIEFILE, $ckfile );
		curl_setopt ( $ch, CURLOPT_COOKIEJAR, $ckfile );
		curl_setopt ( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0" );
		curl_setopt ( $ch, CURLOPT_REFERER, 'http://www.fshare.vn/index.php' );
		
		// execute post
		$result = curl_exec ( $ch );
		curl_close ( $ch );
		unlink ( $ckfile );
	}
	public function get_index($ckfile) {
		$ch = curl_init ();
		
		// set the url, number of POST vars, POST data
		curl_setopt ( $ch, CURLOPT_URL, 'https://www.fshare.vn/index.php' );
		curl_setopt ( $ch, CURLOPT_COOKIEFILE, $ckfile );
		curl_setopt ( $ch, CURLOPT_COOKIEJAR, $ckfile );
		curl_setopt ( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0" );
		curl_setopt ( $ch, CURLOPT_REFERER, 'http://www.fshare.vn/index.php' );
		
		// execute post
		$result = curl_exec ( $ch );
		curl_close ( $ch );
	}
	public function get_redirect($ckfile, $url) {
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_COOKIEFILE, $ckfile );
		curl_setopt ( $ch, CURLOPT_COOKIEJAR, $ckfile );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0" );
		curl_setopt ( $ch, CURLOPT_REFERER, 'https://www.fshare.vn/login.php' );
		curl_setopt ( $ch, CURLOPT_HEADER, 1 );
		
		// execute post
		$result = curl_exec ( $ch );
		
		$curlHeaderSize = curl_getinfo ( $ch, CURLINFO_HEADER_SIZE );
		
		$ResponseData = mb_substr ( $result, $curlHeaderSize );
		$ResponseHeader = mb_substr ( $result, 0, $curlHeaderSize );
		
		curl_close ( $ch );
		if (preg_match ( '/Location:\s*(.*)/mi', $ResponseHeader, $content )) {
			return $content [1];
		}
		
		return "http_logout";
	}
	public function get_size($url) {
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_NOBODY, true );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0" );
		curl_setopt ( $ch, CURLOPT_REFERER, 'https://www.fshare.vn/login.php' );
		curl_setopt ( $ch, CURLOPT_HEADER, 1 );
		curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, true );
		
		// execute post
		$data = curl_exec ( $ch );
		curl_close ( $ch );
		
		if (preg_match ( '/Content-Length: (\d+)/', $data, $matches )) {
			return $matches [1];
		}
		
		return "0";
	}
}
?>
