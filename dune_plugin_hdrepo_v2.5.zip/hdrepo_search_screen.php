<?php
///////////////////////////////////////////////////////////////////////////
require_once 'lib/user_input_handler.php';
require_once 'lib/action_factory.php';
require_once 'lib/control_factory.php';
//require_once 'lib/list_util.php';

///////////////////////////////////////////////////////////////////////////

class HDrepoSearchScreen implements UserInputHandler
{
    const ID = 'search';

    ///////////////////////////////////////////////////////////////////////

	public function get_handler_id(){
		return self::ID;
	}
    
	public function do_get_search_defs(&$plugin_cookies) {
		$defs = array();
		$search_text = isset($plugin_cookies->search) ? $plugin_cookies->search : '';
		$use_osk = isset($plugin_cookies->use_osk) ? $plugin_cookies->use_osk : 'no';
		$this->add_text_field($defs,
				'search', "",
				$search_text, 0, 0,
				($use_osk === 'yes' ? 1 : 0),
				true, 1300, 0, true
		);
		if ($use_osk === 'yes')
			ControlFactory::add_vgap($defs, 500);
		else
			ControlFactory::add_vgap($defs, 50);
	
		$do_search_action = UserInputHandlerRegistry::create_action($this, 'do_search');
	
		ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'apply',
		'Search', 300, $do_search_action);
		ControlFactory::add_close_dialog_button($defs,
		'Close', 300);
	
	
		return $defs;
	}

    protected function add_text_field(&$defs,
    		$name, $title, $initial_value,
    		$numeric, $password, $has_osk, $always_active, $width,
    		$need_confirm = false, $need_apply = false)
    {
    	ControlFactory::add_text_field($defs, $this, null,
    	$name, $title, $initial_value,
    	$numeric, $password, $has_osk, $always_active, $width,
    	$need_confirm, $need_apply);
    }
    
    public function get_control_defs($media_url, &$plugin_cookies)
    {
        return $this->do_get_search_defs($plugin_cookies);
    }

    public function handle_user_input(&$user_input, &$plugin_cookies)
    {
        if ($user_input->control_id == 'do_search' )
        {
        	$control_id = $user_input->control_id;
        	 
        		$new_value = $user_input->{'search'};
        		$search_text = urlencode($new_value);
        		//$plugin_cookies->search = $new_value;
        		//$search_items = isset($plugin_cookies->search_items) ? $plugin_cookies->search_items : '';
        		//$plugin_cookies->search_items = ListUtil::add_item($search_items,$new_value);
        		$search_url = HD::encode_user_data('main_menu',array('provider' => 'search4','param' => $search_text));
        		return array(
        				GuiAction::handler_string_id => PLUGIN_OPEN_FOLDER_ACTION_ID,
        				GuiAction::data =>
        				array(
        						'media_url' => $search_url
        				)
        		);
        }else if ($user_input->control_id == 'search' )
        {
        	$defs = $this->do_get_search_defs($plugin_cookies);
        	
        	return ActionFactory::show_dialog(
        			'Search',
        			$defs);
        	 
        }
        return null;
    }
}

///////////////////////////////////////////////////////////////////////////
?>
