<?php
	require_once "base_menu.php";
	
	class MovieMenu extends BaseMenu
	{
		private $user_data;
		
		function __construct($user_data)
		{
			$this->user_data = $user_data;
		}
		
		public function generate_menu()
		{
			$items = array();
			array_push($items, $this->user_data);
				
			$this->iconFile = "gui_skin://small_icons/video_file.aai";
			$this->action = PLUGIN_VOD_PLAY_ACTION_ID;
			return $this->create_folder_view($items);
		}
	}
?>