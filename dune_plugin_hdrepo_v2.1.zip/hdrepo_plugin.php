<?php
require "main_menu.php";
require "movie_menu.php";
require_once 'lib/control_factory.php';
require_once 'lib/action_factory.php';
require_once 'lib/user_input_handler_registry.php';
require_once 'hdrepo_setup_screen.php';
require_once 'hdrepo_search_screen.php';

	class HDrepoPlugin implements DunePlugin
	{
		public static function get_media_url_str($post_data)
		{
			return MediaURL::encode(
					array
					(
							'screen_id'     => 'main_menu',
							'post_data'   => $post_data,
					));
		}
		
		private $handler;
		
		public function __construct()
		{
			$this->handler = new HDrepoSetupScreen();
			UserInputHandlerRegistry::get_instance()->register_handler($this->handler);
			UserInputHandlerRegistry::get_instance()->register_handler(new HDrepoSearchScreen());
		}		
				
		public function get_folder_view($media_url, &$plugin_cookies)
		{
			HD::decode_user_data($media_url, $media_str, $user_data);
			
			if ($media_str === 'main_menu'){
				if (!is_null($user_data)){
					if ($user_data['type'] === 'fshare_file')
					{
						$menu = new MovieMenu($user_data);
					}
					else
					{
						$menu = new MainMenu($user_data);
					}
				} else {
					$menu = new MainMenu(null);
				}
								
				return $menu->generate_menu();
			}
			else if ($media_str === 'setup'){
				$defs = $this->handler->get_control_defs($media_url, $plugin_cookies);
				
				$folder_view = array
				(
						PluginControlsFolderView::defs => $defs,
						PluginControlsFolderView::initial_sel_ndx => -1,
				);
				
				return array
				(
						PluginFolderView::multiple_views_supported  => false,
						PluginFolderView::archive                   => null,
						PluginFolderView::view_kind                 => PLUGIN_FOLDER_VIEW_CONTROLS,
						PluginFolderView::data                      => $folder_view,
				);
			} 
		}
				
		public function get_next_folder_view($media_url, &$plugin_cookies)
		{
		}

		public function get_tv_info($media_url, &$plugin_cookies)
		{
		}

		public function get_tv_stream_url($media_url, &$plugin_cookies)
		{
		}

		public function get_vod_info($media_url, &$plugin_cookies)
		{
		}

		public function get_vod_stream_url($media_url, &$plugin_cookies)
		{
			return $media_url;
		}

		public function get_regular_folder_items($media_url, $from_ndx, &$plugin_cookies)
		{
		}

		public function get_day_epg($channel_id, $day_start_tm_sec, &$plugin_cookies)
		{
		}

		public function get_tv_playback_url($channel_id, $archive_tm_sec, $protect_code, &$plugin_cookies)
		{
		}

		public function change_tv_favorites($op_type, $channel_id, &$plugin_cookies)
		{
		}

		public function handle_user_input(&$user_input, &$plugin_cookies)
		{
			if ($user_input->control_id == 'play' )
			{
				// Logout current session
				$ckfile = "/tmp/CURLCOOKIE2";
				$this->logout($ckfile);
				
				// Login
				$this->login($ckfile, $plugin_cookies->email, $plugin_cookies->password);
				
				HD::decode_user_data($user_input->selected_media_url, $media_str, $user_data);
					
				$location = $this->get_redirect($ckfile, $user_data['param']);

				if (strpos($location, '.mp4') > 0){
					$location = str_replace('http://', 'http://mp4://', $location);
					hd_print($location);
				} else if (strpos($location, '.ts') > 0){
					$location = str_replace('http://', 'http://ts://', $location);
					hd_print($location);
				} 
				
				return array
				(
						GuiAction::handler_string_id => FILE_PLAY_ACTION_ID,
						GuiAction::data =>
						array
						(
								FilePlayActionData::url => $location
						),
				);
				
			} else if ($user_input->control_id == 'stop' ){
				exec('ps aux | grep -i hdrepo | grep -iv grep | awk {\'print $1\'} | xargs kill -9');
			} else if ($user_input->control_id == 'download' ){
				exec('ps aux | grep -i hdrepo | grep -iv grep | awk {\'print $1\'} | xargs kill -9');

                // Logout current session
                $ckfile = "/tmp/CURLCOOKIE2";
                $this->logout($ckfile);

                // Login
                $this->login($ckfile, $plugin_cookies->email, $plugin_cookies->password);

                HD::decode_user_data($user_input->selected_media_url, $media_str, $user_data);

                $location = $this->get_redirect($ckfile, $user_data['param']);

                $pos1 = strpos($location, '/', 8);
                $pos2 = strrpos($location, '/');
                $param1 = substr($location, 7, $pos1-7);
                $param2 = substr($location, $pos1, $pos2-$pos1);

                hd_print('location ' . $location);

                $pos = strrpos($location, '/');
                if ($pos === false){
                } else {

                	$dir = $this->getFolder();

                    if ($dir == null){
                    	return;
					}
                    $file = '/tmp/mnt/storage/' . $dir . '/temp.mkv';
                    $file2 = 'storage_name://' . $dir . '/temp.mkv';

                    $location = substr( $location, 0,  $pos);
                    hd_print ($file);
                    hd_print ($file2);
                    
                    $fileLength = $this->get_size($location);
                    $len1 = (int)substr($fileLength, 0, strlen($fileLength)-6);
                    $len1 -= 15;

                    $len2 = substr($fileLength, strlen($fileLength)-6);

                    shell_exec ("/flashdata/plugins/HDrepo/bin/createFile $param1 $param2 $file $len1$len2");

                    $cmd = "/flashdata/plugins/HDrepo/bin/hdrepo $param1 $param2 $file > /dev/null 2>/dev/null &";
                    hd_print ( $cmd);
                    $r = shell_exec ($cmd);

                    hd_print ('exec return ' . $r);

                   	sleep(15);
					
					return array
					(
						GuiAction::handler_string_id => FILE_PLAY_ACTION_ID,
						GuiAction::data =>
						array
						(
							FilePlayActionData::url => $file2
						),
					);
				}
				
			}
			
			return UserInputHandlerRegistry::get_instance()->handle_user_input(
            	$user_input, $plugin_cookies);
		}
		
		function getFolder(){
			if ($handle = opendir('/tmp/mnt/storage/.')) {
				$blacklist = array('.', '..');
				while (false !== ($file = readdir($handle))) {
					if (!in_array($file, $blacklist)) {
						closedir($handle);
						return $file;
					}
				}
				closedir($handle);
			}			
		}
		
		function clean($string) {
			//$string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
			return preg_replace('/[^A-Za-z0-9\-\.\_\s]/', '', $string); // Removes special chars.
		}
		
		public function login($ckfile, $email, $password){
		
			//set POST variables
			$url = 'https://www.fshare.vn/login.php';
			$fields = array(
					'login_useremail' => $email,
					'login_password' => $password,
					'url_refe' => 'https://www.fshare.vn/index.php'
			);
		
			$fields_string = '';
		
			//url-ify the data for the POST
			foreach($fields as $key=>$value) {
				$fields_string .= $key.'='.$value.'&';
			}
		
			rtrim($fields_string, '&');
		
			//open connection
			$ch = curl_init();
		
			//set the url, number of POST vars, POST data
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, count($fields));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $ckfile);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $ckfile);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0");
			curl_setopt($ch, CURLOPT_REFERER, 'https://www.fshare.vn/login.php');
			curl_setopt($ch, CURLOPT_HEADER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
					
			//execute post
			$result = curl_exec($ch);
			curl_close($ch);
		}
		
		public function logout($ckfile){
			if (!file_exists($ckfile)){
				return;
			}
		
			$ch = curl_init();
		
			//set the url, number of POST vars, POST data
			curl_setopt($ch, CURLOPT_URL, 'https://www.fshare.vn/logout.php');
			curl_setopt($ch, CURLOPT_COOKIEFILE, $ckfile);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $ckfile);
			curl_setopt($ch, CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0");
			curl_setopt($ch, CURLOPT_REFERER, 'http://www.fshare.vn/index.php');
		
			//execute post
			$result = curl_exec($ch);
			curl_close($ch);
			unlink ($ckfile);
		}

		public function get_index($ckfile){
			$ch = curl_init();
		
			//set the url, number of POST vars, POST data
			curl_setopt($ch, CURLOPT_URL, 'https://www.fshare.vn/index.php');
			curl_setopt($ch, CURLOPT_COOKIEFILE, $ckfile);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $ckfile);
			curl_setopt($ch, CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0");
			curl_setopt($ch, CURLOPT_REFERER, 'http://www.fshare.vn/index.php');
		
			//execute post
			$result = curl_exec($ch);
			curl_close($ch);
		}
		
		public function get_redirect($ckfile, $url){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_COOKIEFILE, $ckfile);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $ckfile);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0");
			curl_setopt($ch, CURLOPT_REFERER, 'https://www.fshare.vn/login.php');
			curl_setopt($ch, CURLOPT_HEADER, 1);
		
			//execute post
			$result = curl_exec($ch);
		
			$curlHeaderSize=curl_getinfo($ch,CURLINFO_HEADER_SIZE);
		
			$ResponseData = mb_substr($result, $curlHeaderSize);
			$ResponseHeader = mb_substr($result, 0, $curlHeaderSize);
		
			preg_match('/Location:\s*(.*)/mi', $ResponseHeader, $content);
		
			curl_close($ch);
		
			return $content[1];
		}
		
		public function get_size($url){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_NOBODY, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0");
			curl_setopt($ch, CURLOPT_REFERER, 'https://www.fshare.vn/login.php');
			curl_setopt($ch, CURLOPT_HEADER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		
			//execute post
		    $data = curl_exec($ch);
    		curl_close($ch);

    		if (preg_match('/Content-Length: (\d+)/', $data, $matches)) {
        		return $matches[1];
			}

        	return "";
		}
	}
?>
