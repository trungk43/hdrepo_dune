<?php
	require_once "lib/utils.php";
	require_once "base_menu.php";
	
	class MainMenu extends BaseMenu
	{
		private $user_data;
		
		function __construct($user_data)
		{
			$this->user_data = $user_data;
		}
		
		
		public function generate_menu()
		{
			if (is_null($this->user_data)){
				$post_data='provider=root&param=&start=0';
			} else {
				$movie = $this->user_data;
				if (isset($movie['start'])){
					$post_data = "provider=" . $movie['provider'] . "&param=" . $movie['param'] . "&start=" . $movie['start'];
				} else {
					$post_data = "provider=" . $movie['provider'] . "&param=" . $movie['param'] . "&start=0";
				}
			}
			
			$data = HD::http_post_document('http://feed.hdrepo.com/v1/feed.php', $post_data);
			$movies = json_decode($data, true);
			
			$menu_items = array();
			
			$folder = true;
			
			foreach ($movies as $movie)
			{
				if ($movie['type'] === 'fshare_file'){					
				} else {
					$folder = false;
				}

				$movie['param'] = str_replace("\+", ' ', $movie['param']);
				
				array_push($menu_items, $movie);
			}
			
			if ($folder){
				$this->iconFile = "gui_skin://small_icons/video_file.aai";
				$this->action = PLUGIN_VOD_PLAY_ACTION_ID;
			}
					
			return $this->create_folder_view($menu_items);
		}
	}
?>