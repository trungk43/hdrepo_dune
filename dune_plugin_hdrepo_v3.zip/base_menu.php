<?php
	abstract class BaseMenu
	{
		protected $iconFile = "gui_skin://small_icons/folder.aai";
		protected $action = PLUGIN_OPEN_FOLDER_ACTION_ID;
		
		protected static function CompareCaption($a, $b)
		{
			$al = strtolower($a["caption"]);
			$bl = strtolower($b["caption"]);
			if ($al == $bl)
			{
				return 0;
			}
			else
			{
				return ($al > $bl) ? +1 : -1;
			}
		}
		
		protected function create_folder_view($items)
		{
			$folderItems = array();
			foreach ($items as $item)
			{
				$folderItems[] = array(
						PluginRegularFolderItem::media_url			=> HD::encode_user_data('main_menu', $item),
						PluginRegularFolderItem::caption			=> $item['title'],
						PluginRegularFolderItem::view_item_params	=> array()
				);
			}

			$search_action = UserInputHandlerRegistry::create_action(UserInputHandlerRegistry::get_handler('search'), 'search');
			$search_action['caption'] = "Search";
			
			if ($this->action == PLUGIN_OPEN_FOLDER_ACTION_ID){
				$play_action = array(
						GuiAction::handler_string_id					=>	$this->action
				);
			} else {
				$play_action = UserInputHandlerRegistry::create_action(UserInputHandlerRegistry::get_handler('search'), 'play');
				$play_action['caption'] = "Play";
			}

// 			$download_action = UserInputHandlerRegistry::create_action(UserInputHandlerRegistry::get_handler('search'), 'download');
// 			$download_action['caption'] = "Play (using cache)";
				
			$stop_action = UserInputHandlerRegistry::create_action(UserInputHandlerRegistry::get_handler('search'), 'stop');
			$stop_action['caption'] = "Stop downloading";

			$find_sub_action = UserInputHandlerRegistry::create_action(UserInputHandlerRegistry::get_handler('search'), 'findsub');
			$find_sub_action['caption'] = "Find Subtitle";
				
			
// 			$quick_play_action = UserInputHandlerRegistry::create_action(UserInputHandlerRegistry::get_handler('search'), 'quickplay');
// 			$quick_play_action['caption'] = "Quick Play";

// 			$menu_items[] = array(
// 					GuiMenuItemDef::caption => 'Find Subtitle',
// 					GuiMenuItemDef::action => UserInputHandlerRegistry::create_action(UserInputHandlerRegistry::get_handler('search'), 'findsub'));			
// 			$popup_menu_action = ActionFactory::show_popup_menu($menu_items);

			return array(
					PluginFolderView::view_kind								=>	PLUGIN_FOLDER_VIEW_REGULAR,
					PluginFolderView::data									=>
						array(
							PluginRegularFolderView::initial_range					=>
								array(
									PluginRegularFolderRange::items							=>	$folderItems,
									PluginRegularFolderRange::total							=>	count($folderItems),
									PluginRegularFolderRange::count							=>	count($folderItems),
									PluginRegularFolderRange::more_items_available			=>	false,
									PluginRegularFolderRange::from_ndx						=>	0
								),
							PluginRegularFolderView::view_params					=>
								array(
									ViewParams::num_cols									=>	1,
									ViewParams::num_rows									=>	11
								),
							PluginRegularFolderView::base_view_item_params			=>
								array(
									ViewItemParams::icon_path								=>	$this->iconFile,
									ViewItemParams::item_layout								=>	HALIGN_LEFT,
									ViewItemParams::icon_valign								=>	VALIGN_TOP,
									ViewItemParams::item_caption_dx							=>	60,
									ViewItemParams::icon_dx									=>	10
									),
							PluginRegularFolderView::not_loaded_view_item_params	=>	array(),
							PluginRegularFolderView::actions						=>
								array(
									GUI_EVENT_KEY_ENTER										=> $play_action,
									//GUI_EVENT_KEY_PLAY										=> $quick_play_action,
									GUI_EVENT_KEY_B_GREEN									=> $search_action,
									GUI_EVENT_KEY_C_YELLOW									=> $find_sub_action,
									GUI_EVENT_KEY_D_BLUE									=> $stop_action,
									GUI_EVENT_PLAYBACK_STOP									=> $stop_action
									//GUI_EVENT_KEY_POPUP_MENU								=> $popup_menu_action
								)
						)
					);
		}
		
		abstract public function generate_menu();
	}
?>