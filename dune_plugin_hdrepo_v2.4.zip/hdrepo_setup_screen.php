<?php
///////////////////////////////////////////////////////////////////////////
require_once 'lib/user_input_handler.php';
require_once 'lib/action_factory.php';
require_once 'lib/control_factory.php';

///////////////////////////////////////////////////////////////////////////

class HDrepoSetupScreen implements UserInputHandler
{
    const ID = 'setup';

    ///////////////////////////////////////////////////////////////////////

	public function get_handler_id(){
		return self::ID;
	}
    
    public function do_get_control_defs(&$plugin_cookies)
    {
        $defs = array();

        if (isset($plugin_cookies->email))
            $email = $plugin_cookies->email;
        else
            $email = '';

        $this->add_text_field($defs,
            'email', 'Email',
            $email, false, false, false, true,
            500, true, true);

        if (isset($plugin_cookies->password))
        	$password = $plugin_cookies->password;
        else
        	$password = '';
        
        $this->add_text_field($defs,
        		'password', 'Password',
        		$password, false, true, false, true,
            500, true, true);
        
        $this->add_close_dialog_button($defs,
        		'Apply', 300 
        		);
        return $defs;
    }

    protected function add_text_field(&$defs,
    		$name, $title, $initial_value,
    		$numeric, $password, $has_osk, $always_active, $width,
    		$need_confirm = false, $need_apply = false)
    {
    	ControlFactory::add_text_field($defs, $this, null,
    	$name, $title, $initial_value,
    	$numeric, $password, $has_osk, $always_active, $width,
    	$need_confirm, $need_apply);
    }
    
    protected function add_close_dialog_and_apply_button(&$defs,
        $name, $caption, $width)
    {
        ControlFactory::add_close_dialog_and_apply_button($defs,
            $this, null,
            $name, $caption, $width);
    }

    protected function add_close_dialog_button(&$defs,
    		$caption, $width)
    {
    	ControlFactory::add_close_dialog_button($defs,
    	$caption, $width);
    }    
        
    public function get_control_defs($media_url, &$plugin_cookies)
    {
        return $this->do_get_control_defs($plugin_cookies);
    }

    public function handle_user_input(&$user_input, &$plugin_cookies)
    {
        hd_print('Setup: handle_user_input:');
        foreach ($user_input as $key => $value)
            hd_print("  $key => $value");

        $need_reset_controls = false;
        if (isset($user_input->control_id))
        {
            $control_id = $user_input->control_id;
            $new_value = $user_input->{$control_id};
            hd_print("Setup: changing $control_id value to $new_value");

            if ($control_id === 'email')
                $plugin_cookies->email = $new_value;
            else if ($control_id === 'password')
                $plugin_cookies->password = $new_value;

            $need_reset_controls = true;
        }

        if ($need_reset_controls)
        {
            $defs = $this->do_get_control_defs($plugin_cookies);
            return ActionFactory::reset_controls($defs);
        }

        return null;
    }
}

///////////////////////////////////////////////////////////////////////////
?>
